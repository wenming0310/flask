把yetone用tornado写的[Bruce](https://github.com/yetone/bruce)，改成用Flask实现，UI不变。


bruce
=====

http://blog.yetone.net 的源代码。